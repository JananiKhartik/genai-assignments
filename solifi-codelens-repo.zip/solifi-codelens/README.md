# Solifi CodeLens — AI GitHub Code Reviewer

An AI code reviewer built with **n8n** and a **Groq-hosted LLM**. You paste a GitHub file link into the CodeLens web UI. n8n fetches the raw source and asks the LLM to review it. The review comes back with five parameter scores (each out of 20), an overall score out of 100, improvement areas and a summary.

```
Browser (CodeLens UI) ──POST {url}──▶ n8n Webhook ──▶ HTTP Request (GET raw file)
        ▲                                                      │
        └──── JSON {review} ◀── Respond to Webhook ◀── Basic LLM Chain ◀── Groq Chat Model
```

## Repository layout
| Path | Contents |
|---|---|
| `codelens-ui/index.html` | Complete UI: a single file with HTML, CSS and JavaScript |
| `n8n/AI_GitHub_Code_Reviewer.workflow.json` | The n8n workflow, ready to import |
| `prompts/Code_Review_Prompt.txt` | The LLM review prompt used in the Basic LLM Chain |
| `prompts/UI_Development_Prompt.md` | The prompt used to generate the UI |
| `docs/` | Assignment PDF and screenshots |

## Run locally
1. **Start n8n:** `npx n8n` (or Docker). It opens at http://localhost:5678.
2. **Import the workflow:** go to *Workflows → Import from file* and pick `n8n/AI_GitHub_Code_Reviewer.workflow.json`.
3. **Add your Groq key:** open the *Groq Chat Model* node and create a **Groq API** credential with your key from console.groq.com.
4. **Activate the workflow.** The production URL is `http://localhost:5678/webhook/code-review`.
5. **Serve the UI:** `cd codelens-ui && python -m http.server 8765`, then open http://127.0.0.1:8765.
6. **Run a review:** paste a GitHub file URL and click **Review Code**.

## Quick API test
```bash
curl -X POST http://localhost:5678/webhook/code-review \
  -H "Content-Type: application/json" \
  -d '{"url":"https://raw.githubusercontent.com/<owner>/<repo>/main/<path>/File.java"}'
```
